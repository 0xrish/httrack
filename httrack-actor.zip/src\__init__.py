# Actor initialization

