import asyncio

from .main import main

# Execute the Actor entry point.
asyncio.run(main())
